//___FILEHEADER___

#ifndef ___PACKAGENAMEASIDENTIFIER____
#define ___PACKAGENAMEASIDENTIFIER____

/* The classes below are exported */
#pragma GCC visibility push(default)

class ___PACKAGENAMEASIDENTIFIER___
{
    public:
    void HelloWorld(const char *);
};

#pragma GCC visibility pop
#endif
